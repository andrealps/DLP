package ast;

import errorhandler.ErrorType;
import visitor.Visitor;

public class Array extends AbstractType{
    private int size;
    private Type type;

    public Array(int line, int column, int size, Type type) {
        super(line, column);
        this.size = size;
        this.type = type;
    }

    public int getSize() {
        return size;
    }

    public Type getType() {
        return type;
    }

    @Override
    public Object accept(Visitor v, Object p){
        return v.visit(this, p);
    }

    @Override
    public Type squareBrackets(Type type) {
        if (type instanceof ErrorType)
            return type;
        else if (type instanceof IntType)
            return this.type;
        else
            squareBrackets(type);
        return null;
    }
}
