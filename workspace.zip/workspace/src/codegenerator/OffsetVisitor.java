package codegenerator;

import visitor.AbstractVisitor;

public class OffsetVisitor extends AbstractVisitor {
}
